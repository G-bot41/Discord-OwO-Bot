/*
 * OwO Bot for Discord
 * Copyright (C) 2019 Christopher Thai
 * This software is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
 * For more information, see README.md and LICENSE
  */

exports.alter = function(id,text){
	if(id==220934553861226498)
		return geist(text);
	else
		return text;
}

function geist(text){
	return text;
}
